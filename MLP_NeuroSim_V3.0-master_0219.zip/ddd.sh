#!/bin/bash
  
for j in 0 2 4 6
do
make
make run
make clean
mv Train.cpp Train.txt;
let k=${j}
let ka=(${j}+2);
sed -i s/GAMA=$k/GAMA=$ka/ Train.txt;
mv Train.txt Train.cpp;
done

mv Train.cpp Train.txt;
sed -i s/GAMA=8/GAMA=0/ Train.txt;
mv Train.txt Train.cpp;
