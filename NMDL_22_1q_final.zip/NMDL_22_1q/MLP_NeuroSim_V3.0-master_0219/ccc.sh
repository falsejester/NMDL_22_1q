#!/bin/bash
  
for j in 1 3 5 7
do
make
make run
make clean
mv Cell.cpp Cell.txt;
let ja=$j+2;
sed -i 's/'NL_LTP=$j'/'NL_LTP=$ja'/' Cell.txt;
mv Cell.txt Cell.cpp;
done

mv Cell.cpp Cell.txt;
sed -i 's/'NL_LTP=9'/'NL_LTP=1'/' Cell.txt;
mv Cell.txt Cell.cpp;
