#!/bin/bash
for i in 0 1 2 3 4 5
do
for j in 1 3 5 7 9
do
make
make run
make clean
mv Train.cpp Train.txt;
let k=${j};
let ka=(${j}+2);
sed -i s/GAMA=$k/GAMA=$ka/ Train.txt;
mv Train.txt Train.cpp;
done

mv Train.cpp Train.txt;
sed -i s/GAMA=11/GAMA=1/ Train.txt;
mv Train.txt Train.cpp;

mv Cell.cpp Cell.txt;
let l=${i};
let la=(${i}+1)
sed -i s/NL_LTP=$l/NL_LTP=$la/ Cell.txt;
mv Cell.txt Cell.cpp;
done

mv Cell.cpp Cell.txt;
sed -i s/NL_LTP=6/NL_LTP=0/ Cell.txt;
mv Cell.txt Cell.cpp;